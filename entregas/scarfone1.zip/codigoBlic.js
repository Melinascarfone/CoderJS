function saludar(){
    alert("Bienvenido a Libreria BLIC");
}
saludar();
class Producto{
    constructor(producto, color, marca, cantidad, precio, total){
        this.producto = producto.toLowerCase();
        this.color = color.toLowerCase();
        this.marca = marca.toLowerCase();
        this.cantidad = parseInt(cantidad);
        this.precio = parseFloat(precio);
        this.total = parseFloat(total);
    }
    resumir(){
        alert(this.producto + " " + this.marca + ". Color: "+ this.color);
    }
    calcular(){
        this.total = this.cantidad * this.precio
        alert("Precio: $" + this.total + " x" + this.cantidad + " unidades");
    }
}

let condicion = true;

do{
    let producto = prompt("Ingrese el producto: ");
    let color = prompt("Ingrese el color: ");
    let marca = prompt("Ingrese la marca: ");
    let cantidad = parseInt(prompt("Ingrese la cantidad: "));
    let precio = parseFloat(prompt("Ingrese el precio: "));
    let total;

    const producto1 = new Producto(producto,color,marca, cantidad, precio, total);
    producto1.resumir();
    producto1.calcular();

    condicion = confirm("Queres agregar otro producto?");

}
while(condicion != false)

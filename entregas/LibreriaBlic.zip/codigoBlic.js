let campoMail = document.getElementById("mail");
campoMail.onchange = () => { 
    console.log("Se ingreso un mail"); 
}
let campoMensaje = document.getElementById("mensaje");
campoMensaje.onchange = () => { 
    console.log("Se ingreso un nuevo mensaje"); 
}
campoMail.onfocus = () => { 
    campoMail.style = "background-color: #FFECD8;"
}
campoMensaje.onfocus = () => { 
    campoMensaje.style = "background-color: #FFECD8;"
}

function saludo() {
     alert("Hola "+ campoMail.value + " recibiras mails con todas las novedades!" );
}

let miFormulario = document.getElementById("formUno");
miFormulario.addEventListener("submit", validarFormUno);

function validarFormUno(e) {
    e.preventDefault();
    saludo()
}

let boton1 = document.getElementById("boton1");

let titulo = document.getElementById("tit");

boton1.onclick = () => { 
    titulo.innerHTML= "Gracias por contactarnos!"
}
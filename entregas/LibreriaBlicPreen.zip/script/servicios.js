// Variables
const datosServicios =[{id: 1,nombre:'Impresiones - Fotocopias - Escaneos', datos:'holaholaholaholaholaholahola', imagen:'../galeria/fotocopias.png'},
{id: 2,nombre:'Anillados', datos:'holaholaholaholaholaholahola', imagen:'../galeria/anillados.png'},
{id:3, nombre:'Plastificados', datos:'holaholaholaholaholaholahola', imagen:'../galeria/plastificado.jpg'}
];

const DOMitems = document.getElementById('items');

//Dibujo todos los productos a partir de las variables
function catalogoServicios() {
  datosServicios.forEach((info) => {
      const cat = document.createElement('div');
      cat.classList.add('card', 'col-sm-4');
      const cardBody = document.createElement('div');
      cardBody.classList.add('card-body');
      const titulo = document.createElement('h5');
      titulo.classList.add('card-title');
      titulo.textContent = info.nombre;
      const imagen = document.createElement('img');
      imagen.classList.add('img-fluid');
      imagen.setAttribute('src', info.imagen);
      const datos = document.createElement('p');
      datos.classList.add('card-text');
      datos.textContent = info.datos;
      const boton = document.createElement('button');
      boton.classList.add('card-button', 'btn', 'btn-outline-secondary');
      boton.textContent = 'Agregar al carrito';
      boton.setAttribute('marcador', info.id);
      boton.addEventListener('click', agregarProductoAlCarrito);
   
      cardBody.appendChild(imagen);
      cardBody.appendChild(titulo);
      cardBody.appendChild(datos); 
      cardBody.appendChild(boton);
      cat.appendChild(cardBody);
      DOMitems.appendChild(cat);
  });
}
const hojas = [{nombre: "Hojas N3", marca: "Rivadavia", cantidad: "48 hojas", precio: "220"},
    {nombre: "Hojas N3", marca: "Rivadavia", cantidad: "98 hojas", precio: "390"},
    {nombre: "Hojas N3", marca: "Exito", cantidad: "48 hojas", precio: "210"},
    {nombre: "Hojas N3", marca: "Exito", cantidad: "90 hojas", precio: "970"}
];
for (const producto of hojas) {
    let contenedor = document.createElement("div");
    contenedor.innerHTML = `<h3> ID: ${producto.nombre}</h3>
                            <p>  Producto: ${producto.marca}</p>
                            <p>  Producto: ${producto.cantidad}</p>
                            <b> $ ${producto.precio}</b>`;
    document.body.appendChild(contenedor);
}